# Cart Migration Guide for Magento 2

## Installation
Please follow the guide for "For Magento 2.x on Magento Marketplace" on http://litextension.com/docs/magento-cart-migration-guide/


## Contact
For all questions, bug reports, you can reach us at http://litextension.com/contacts